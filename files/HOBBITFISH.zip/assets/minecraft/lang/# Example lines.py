import os
import json

# Define the paths to the two files
file_path1 = "C:/Users/Derp/Downloads/fish.json"
file_path2 = "C:/Users/Derp/Downloads/Resources/assets/minecraft/lang/en_us.json"

# Open both files simultaneously
with open(file_path1, 'r') as f1, open(file_path2, 'r') as f2:
    # Read the entire content of the first file
    data1 = json.load(f1)

    # Iterate over the lines of the second file
    for line2 in f2:
        try:
            # Replace single quotes with double quotes
            line2 = line2.replace("'", "\"")

            # Parse line 2 as JSON
            data2 = json.loads(line2)
            print("Data 2:", data2)

            # Check if data2 is a non-empty dictionary
            if isinstance(data2, dict) and data2:
                # Get the first key of data2
                data2_key = next(iter(data2))
                # Get the corresponding value from data1 if the key is numeric
                if data2_key.isdigit():
                    value_index = int(data2_key) - 1
                    custom_model_data_number = data1[value_index]["predicate"]["custom_model_data"]
                    # Update the language entry with the custom model data number
                    data2_value = data2[data2_key]
                    data2[data2_key] = f"{data2_value} C{custom_model_data_number}"
                    # Output the updated line 2
                    print(json.dumps(data2))
                else:
                    print("Warning: Skipping non-numeric key in data2")
            else:
                print("Error: data2 is not a non-empty dictionary")

        except KeyError as e:
            print(f"KeyError: {e}")
        except json.JSONDecodeError as e:
            print(f"JSONDecodeError: {e}")
        except Exception as e:
            print(f"Error processing lines: {e}")
