Terms of Use:

Please credit me should you feature this pack anywhere. You may refer to me as Athesiel, link to my twitter at twitter.com/athesiel, and respect the information found in my bio there.
That's pretty much my only request. Thanks! <3